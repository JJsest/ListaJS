const cavalos = parseInt(prompt("Digite o número de cavalos:"));
const ferraduras = cavalos * 4;
document.getElementById("resultado").innerText = `Você precisará de ${ferraduras} ferraduras.`;
